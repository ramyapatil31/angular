export default class Student{
	id: number;
	firstName: string;
	lastName: string;
	email: string;
	phone: string;

}